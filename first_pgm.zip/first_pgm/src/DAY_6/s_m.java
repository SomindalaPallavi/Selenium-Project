package DAY_6;

import java.util.Scanner;

public class s_m {
	
	static String[][] st={{"11","sathish"},{"12","sai"},{"13","pallu"},{"14","pooja"}};
	static int[][] marks={{11,90,80},{12,91,81},{13,25,88},{14,68,90}};
	static int i;
	
	public int calc_avg(int k)
	{
		int avg=(marks[k][1]+marks[k][2])/2;
		return avg;
		
	}
	
	public int search(String std)//search std id in marks array
	{
		int id=Integer.parseInt(std);
		int index = 0;
		for(int i=0;i<=3;i++)
		{
			if(id==marks[i][0])
			{
				index=i;
				break;//come out of the for loop
			}
		}
		return index;//1
		
	}
	
	
	public static String getname(String id)
	{
		String n = null;
		for(int i=0;i<=3;i++)
		{
			if(id.equals(st[i][0]))
			{
				
				n=st[i][1];
				break;
			}
		}
		return n;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println("enter the string: ");
//		Scanner scanner=new Scanner(System.in);
//		String s1=scanner.next();
		s_m s=new s_m();
		String name=s.getname("01");
		int k=s.search("01");
		
		int c=s.calc_avg(k);
	
	   // String index;
		System.out.println(marks[k][0]+" "+name+" "+c);
		
		
	}

}
