package DAY_2;

public class Pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int a=10,b=2,c;
    int m[]={1,3,5,6};
   // try{
    	//System.out.println("before");
        c=a/b;
        //System.out.println("after");
    //}
   // catch(Exception e){
   // 	System.out.println("inside the block");
  //  }
    System.out.println(m[4]);
	}

}
