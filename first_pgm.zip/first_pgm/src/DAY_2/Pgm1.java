package DAY_2;

public class Pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    float sum=0;
   
    int[] marks={95,91,85,86,90,77,71,81};
    for(int i=0;i<=7;i++){
    	sum=sum+marks[i];
    }
    System.out.println(sum);
    float avg=(sum)/8;
    System.out.println(avg);
	if(avg>=70)
	{
		System.out.println("first class with distinct "+avg);
	}
	else if((avg>=60)&&(avg<70))
	{
		System.out.println("first class "+avg);
	}
	else
	{
		System.out.println("second class "+avg);
	}
	
  
	}
	}
