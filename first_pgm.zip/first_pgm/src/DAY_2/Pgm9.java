package DAY_2;

public class Pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int max,r,c;
		int[][] m={{18,4,-2,29},{-8,99,23,18},{199,67,309,47}};
		 for(r=0;r<=2;r++)
		    {
			 max=18;
		    	for(c=0;c<=3;c++)
		    	{
		    		if(max<m[r][c])
		    		{
		    			//System.out.println(max);
		    			max=m[r][c];
		    			//System.out.println(max);
		    		}
		    		
		    		
		    	}
		    	System.out.println(max);
		    }
		 
		}
	}

	