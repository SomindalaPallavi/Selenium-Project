package DAY_2;

public class Pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=30;boolean prime=true,x,r;
		//for(x=2;x<=n/2;x++)
		//{
		//	r=n%x;
		//	if(r==0)
		//	{
		//		prime=false;
		//		break;
			//}
	//	} 
		if(prime==true)
		{
			System.out.println(n+ "is prime");
		}
		else
		{
			System.out.println(n+"is not prime");
		}
	}

}
