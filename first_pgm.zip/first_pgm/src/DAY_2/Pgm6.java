package DAY_2;

public class Pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0,p=0,p1=0;
		String s1;
		String s="I am learning core java";
		while(p1!=-1){
			p=s.indexOf(" ",i);
			p1=p;
			if(p==-1)
			{
               p=s.length();
			}
            System.out.println("i = "+ i +" " +"p = "+p);
			s1=s.substring(i,p);
		    System.out.println(s1);
			i=p+1;
		
		}
		
	}

}
