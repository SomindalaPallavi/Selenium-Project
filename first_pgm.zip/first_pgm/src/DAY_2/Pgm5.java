package DAY_2;

public class Pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c = 0,i=0,p=0;
		String s="I am learning core java";
		while(p>=0){
			p=s.indexOf(" ",i);
			c++;
			i=p+1;
			
		}
		System.out.println("no of words in a sentence:"+c);
		c=c-1;
		System.out.println("no of spaces in a sentence:"+c);
	}

}
