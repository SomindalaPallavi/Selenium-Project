package DAY_2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Puttur",s1="Puttur",s2="puttur";
		int l=s1.length();
		System.out.println("length "+l);
		
		int c=s.compareTo(s2);
		System.out.println("length = "+ l + " "+"Return Value: "+c);
		
		int i=s.compareToIgnoreCase(s2);
		System.out.println("length = "+ l + " "+"Return Value: "+i);
		
		String s3=s.substring(0,4);
		System.out.println("Substring :"+s3);
		
		int p=s.indexOf("t",0);
		System.out.println("position: "+p);
		
		int p1=s.indexOf("t",p+1);
		System.out.println("2nd position of n:"+p1);
		
	}

}
