package DAY_2;

public class Pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float sum=0;
		   
	    int[] marks={95,91,85,86,90,77,71,81};
	    for(int i=0;i<=7;i=i+2)
	    {
	    	if(marks[i]%2!=0){
	    	sum=sum+marks[i];
	        }
	    }
	    System.out.println(sum);
	}

}
