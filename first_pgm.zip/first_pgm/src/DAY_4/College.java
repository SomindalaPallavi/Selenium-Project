package DAY_4;

public class College{


public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student sai=new Student(98,99, 96, "pallu");
		
		//sai.java=98;
		//sai.testing=99;
		sai.calculateAvg();
		
		System.out.println("Average marks of sai= "+sai.avg);
		Student pooja=new Student(95,96, 99, "sai");
		//pooja.java=95;
		//pooja.testing=96;
		pooja.calculateAvg();
		
		System.out.println("Average marks of pooja= "+pooja.avg);
	}

}
