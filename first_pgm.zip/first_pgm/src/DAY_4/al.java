package DAY_4;

import java.util.ArrayList;

public class al {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str_al=new ArrayList<String>();
		str_al.add("sai");
		str_al.add("pallu");
		str_al.add("vasu");
		str_al.add("pooja");
		
		System.out.println("Before Insertion : "+str_al);
		
		str_al.add(2,"pavi");
		
		System.out.println("After Insertion : "+str_al);
		
		str_al.remove("pooja");
		
		System.out.println("After Deletion : "+str_al);
		
		str_al.remove(2);
		
		System.out.println("After Deletion : "+str_al);
		
		for(String s : str_al)
		{
			System.out.println(s);
		}
	}
	

}
