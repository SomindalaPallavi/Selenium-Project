package DAY_4;

import java.util.Scanner;

public class ex{

	int i,j;
	static int index;
	static int z;
		
		
	public int calc_avg(int m1,int m2)
	{
		int avg=(m1+m2)/2;
		return avg;
	}
	
	public int search(String st)
	{
		int z=Integer.parseInt(st);
		
		return z;
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] st={{"11","sathish"},{"12","sai"},{"13","pallu"},{"14","pooja"}};
		int[][] marks={{12,90,80},{13,91,81},{11,25,88},{14,68,90}};
		
		System.out.println("enter string : ");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		ex c=new ex();
		for(int i=0;i<=3;i++)
		{
			//int se=c.search(st[i][0]);
				if(z==marks[i][0])
				{
					index=i;
		          //System.out.println(st[i][0]+" "+st[i][1]+" "+c.calc_avg(marks[i][1], marks[i][2]));
				}

		}
		
	}

}
