package DAY_4;
import java.util.Scanner;
public class Pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] emp={{"e1","satish"},{"e2","sai"},{"e3","pallu"},{"e4","pooja"}};
		System.out.println("enter string: ");
		Scanner scanner=new Scanner(System.in);
		String s=scanner.next();
		for(int i=0;i<=3;i++)
		{
		    int e=emp[i][0].compareTo(s);
			if(e==0)
				
			    System.out.println(emp[i][1]);
			
		 }
	 }

}
