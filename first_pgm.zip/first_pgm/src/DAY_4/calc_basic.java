package DAY_4;

public class calc_basic {
	
	public int add(int x,int y)
	{
		int a=x+y;
		return a;
	}
	
	public int add(int x,int y,int z)
	{
		int b=x+y+z;
		return b;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calc_basic c=new calc_basic();
		System.out.println(c.add(2,4));
		System.out.println(c.add(2,4,5));
	
	}

}
