package DAY_4;

import java.util.Scanner;

public class student_marks {
	
	private static int i1;
	private static int j;
	private int[][] marks;
	private Object[][] st;
	private Object id;
	private int i;
	

	public int calc_avg(int marks1, int marks2)
	{
		int avg;
		avg=(marks1+marks2)/2;
		return avg;
	}
	
	public int search(String num)
	{
	
		int id=Integer.parseInt(num);
		return id;
		//int index = 0;
		//for(int i=0;i<=3;i++)
		//{
				//if(id==marks[i][0])
				//{
				//  index=i;
				//  break;
				//}
		//}
	
	}
	
	
//	public String getname(String id)
//	{
//		String n = null;
//		for(int j=0;j<=3;j++)
//		{
//			if(id.equals(st[j][0]))
//			{
//				
//				n=(String) st[j][1];
//				break;
//			}
//		}
//		return n;
//	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] st={{"11","sathish"},{"12","sai"},{"13","pallu"},{"14","pooja"}};
		int[][] marks={{12,90,80},{13,91,81},{11,25,88},{14,68,90}};
		System.out.println("enter the string : ");
		Scanner scanner=new Scanner(System.in);
		int se=scanner.nextInt();
		System.out.println(se);
		student_marks sm=new student_marks();
		System.out.println("stid " + "Name " + "average ");
		
		for(int i1=0;i1<=3;i1++)
		{
			int i=sm.search(st[i1][0]);
			
			if(i==se)
				
				for(int j=0;j<=3;j++)
				{
				  if(i==marks[j][0])
				  {
					//index=i;
					//break;
					 int av=sm.calc_avg(marks[j][1], marks[j][2]);
					 System.out.println(i+" "+st[i1][1]+" "+av);
				  }
				}
				 
		}
	}
}
		

