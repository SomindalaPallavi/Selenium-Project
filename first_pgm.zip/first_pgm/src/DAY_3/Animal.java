package DAY_3;

public class Animal {
	 int height,weight,age;
	 String colour;
	 
	public void display()
	{
		 System.out.println("height ="+height +" "+ "weight ="+weight +" " + "age ="+age +" "+ "colour ="+colour);
	 }

}