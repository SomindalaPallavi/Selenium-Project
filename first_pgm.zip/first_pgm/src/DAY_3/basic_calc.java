package DAY_3;

public class basic_calc {

	int num1=3,num2=4;
	public void add(int num1,int num2){
		int n=num1+num2;
		System.out.println(n);
	}
	public void subtract(int num1,int num2){
		int N=num1-num2;
		System.out.println(N);
	}
}
