package DAY_3;

public class Zoo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Elephant a=new Elephant();
		a.height=6;
		a.weight=200;
		a.age=25;
		a.colour="grey";
		a.lotrunk=2;
		a.lotusk=1;
		a.display_details();

	}

}
