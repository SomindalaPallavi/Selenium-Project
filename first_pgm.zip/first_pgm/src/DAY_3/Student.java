package DAY_3;

public class Student {

		int id;
		String name;
		int testing;
		int java;
		float avg;
		void calculateAvg(){
			avg=(testing+java)/2.0f;
		}
	
public static void main(String[] args) {
	// TODO Auto-generated method stub
	Student sai=new Student();
	Student pooja=new Student();
	sai.testing=95;
	sai.java=90;
	sai.calculateAvg();
	pooja.testing=93;
	pooja.java=94;
	pooja.calculateAvg();
	System.out.println("Average marks of sai= "+sai.avg);
	System.out.println("Average marks of pooja= "+pooja.avg);
 }
}
