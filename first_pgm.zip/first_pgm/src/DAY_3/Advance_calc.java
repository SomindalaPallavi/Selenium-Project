package DAY_3;

public class Advance_calc extends basic_calc{
	
	public int multiply(int num1,int num2){
		int mul=num1*num2;
		return mul;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Advance_calc a=new Advance_calc();
		int d=a.multiply(3,4);
		System.out.println("d ="+d);
	}

}
