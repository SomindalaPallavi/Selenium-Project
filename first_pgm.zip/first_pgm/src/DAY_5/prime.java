package DAY_5;

public class prime {
	
	public static void main(String[] args){
		
		int i,num=11,count=1;
		
		for(i=2;i<=num/2;i++)
		{
			if(num%i==0)
			{
				count=0;
				break;
			}
		}
		if(count==1)
		{
			System.out.println("PRIME NUMBER");
		}
		else
		{
			System.out.println("NOT A PRIME NUMBER");
		}
	}

}
