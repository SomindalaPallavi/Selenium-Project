package DAY_5;

public class icici extends bank{
	
	float get_roi(){
		
		return 8.5f;
	}
}
