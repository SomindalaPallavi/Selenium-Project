package DAY_5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class w_e {
private String String;



public String write_excel(String Filename,String Sheetname,int r,int c,String n){
		
		String s = null;
		 try {
		    	File f=new File(Filename);
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet(Sheetname);
				XSSFRow row=sh.getRow(r);
				XSSFCell cell=row.getCell(c);
			    //s=cell.getStringCellValue();
				//System.out.println(s);
				
				cell.setCellValue(n);
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
		 		
//		 		c.setCellValue(s);
//		 		FileOutputStream fos=new FileOutputStream(f);
//		 		wb.write(fos);
		 		
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return s;
		     
			}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		w_e r=new w_e();
		String p=r.write_excel("C:\\Users\\BLTuser.BLT223\\Desktop\\New folder\\1.xlsx","Sheet1",0,0,"Chennai");
		//System.out.println(p);
	}

}
