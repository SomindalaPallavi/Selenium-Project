package DAY_5;

public class hdfc extends bank{
	
	float get_roi(){
		
		return 9.5f;
	}

}
