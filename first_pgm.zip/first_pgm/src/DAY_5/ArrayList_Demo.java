package DAY_5;

import java.util.ArrayList;

public class ArrayList_Demo{

	ArrayList<Student> std_al =new ArrayList<Student>();
	
	public void create_al()
	{
	Student s1=new Student(90,100,80,"sai");
	Student s2=new Student(91,100,89,"sai1");
	std_al.add(s1);
	std_al.add(s2);
	}
	
	public void display_al()
	{
		for(Student s : std_al)
		{
			System.out.println("Name = " + s.name+" "
					+"ID = " + s.id+" "
					+"Sel marks = " + s.selenium+" "
					+"Java marks = " + s.java);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList_Demo al=new ArrayList_Demo();
		al.create_al();
		al.display_al();
	}

}
