package DAY_5;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class text_io {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileInputStream fin=new FileInputStream("C:\\Users\\BLTuser.BLT223\\Desktop\\New folder\\1.txt");
			int i;
			while((i = fin.read())!=-1)
			{
				System.out.print((char)i);
			}
			fin.close();
			
			FileOutputStream fos=new FileOutputStream("C:\\Users\\BLTuser.BLT223\\Desktop\\New folder\\1.txt");
			byte[] d= "I am learning Testing".getBytes();
			fos.write(d);
			fos.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
