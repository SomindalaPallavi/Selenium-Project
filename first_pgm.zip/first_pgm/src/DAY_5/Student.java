package DAY_5;

public class Student {
	int id;
	String name;
	int testing;
	int java;
	float avg;
	public String selenium;
	
	public Student(int testing,int java,int id,String name)
	{
		
		this.name=name;
		this.id=id;
		this.java=java;
		this.testing=testing;
	}
	void calculateAvg(){
		avg=(testing+java)/2.0f;
	}
}
