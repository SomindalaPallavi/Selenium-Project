package DAY_1;

public class Pgm14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=2516;
		String s=String.valueOf(n);
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			switch(ch)
			{
			case '1':
				System.out.print("one");
			case '2':
				System.out.print("two");
			case '3':
				System.out.print("three");
			case '4':
				System.out.print("four");
			case '5':
				System.out.print("five");
				}
			System.out.println(" ");
		}
		
	}

}
