package DAY_1;

public class Pgm6 {

	public static void main(String[] args){
		long sal=200000;
		long s = 0,s1 = 0,s2;
		float t1,t2,t3,T1,T2;
	    if(sal<180000){
	    	System.out.println("no tax");
	    }
	    else if((sal>180000)&&(sal<500000))
	    {
	    	s=sal-180000;
	    	t1=s*(0.1f);
	    	System.out.println("s= "+s);
	    	System.out.println("t1= "+t1);
	    	
	    }
	    if((sal>=500000)&&(sal<=800000))
	    {
	    	s1=sal-500000;
	    	t2=s1*(0.2f);
	    	t1=s*(0.1f);
	    	T1=t1+t2;
	    	System.out.println("s1= "+s1);
	    	System.out.println("t2= "+t2);
	    	System.out.println("T1= "+T1);
	    }
	    if(sal>800000)
	    {
	    	s2=sal-800000;
	    	t3=s2*(0.3f);
	    	s1=sal-500000;
	    	t2=s1*(0.2f);
	    	s=sal-180000;
	    	t1=s*(0.1f);
	    	T2=t1+t2+t3;
	    	System.out.println("s2= "+s2);
	    	System.out.println("t3= "+t3);
	    	System.out.println("T2= "+T2);
	    }
	    	
	}
}
