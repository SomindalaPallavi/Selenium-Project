package DAY_1;

public class Pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int a=4,b=20;
		    if(a>b){ 
		    	System.out.println(a+ " is greater than "+b);
		    	System.out.println("Inside the block");
			}
			else if(a==b)
				System.out.println(a+ " is equal to "+b);
			else
				System.out.println(a+ " is less than "+b);
		}
}