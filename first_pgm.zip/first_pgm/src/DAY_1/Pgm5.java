package DAY_1;

public class Pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int a=10,b=2,c=5;
    if(a<b)
    {
      if(a<c)
          System.out.println(a+" is a smallest num");
      else
    	  System.out.println(c+" is a smallest num");
    }
    else if(b<c)
    	System.out.println(b+" is a smallest num");
    else
    	System.out.println(c+" is a smallest num");
   
	}
  
}
