package DAY_1;

public class Pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
    int r,sum=0,n=59138;
    while(n>0){
    	r=n%10;
    	if(r>5){
    	sum=sum+r;
    	}
    	n=n/10;
    }
    System.out.println(sum);
	
    
	}

}
