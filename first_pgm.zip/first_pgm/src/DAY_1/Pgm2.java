package DAY_1;

public class Pgm2 {
 public static void main(String[] args){
	 int i=0,j=2;
	 boolean b=(i>j)&&(j++>i);
	 boolean b1=(i<j)||(j<10);
	 boolean b2=!(j<i);
	 System.out.println("j =" + j);
	 System.out.println("b =" + b);
	 System.out.println("b1 =" + b1);
	 System.out.println("b2 =" +b2);
 }
}
