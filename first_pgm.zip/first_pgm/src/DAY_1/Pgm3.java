package DAY_1;

public class Pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int a=21,b=20;
    if(a>b){ 
    	System.out.println(a+ " is greater than "+b);
    	System.out.println("Inside the block");
	}
	else
	{
		System.out.println(a+ " is not greater than "+b);
	}
}
}