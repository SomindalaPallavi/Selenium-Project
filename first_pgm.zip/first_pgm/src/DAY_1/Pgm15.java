package DAY_1;

public class Pgm15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0,num=3452;
		while(num!=0)
		{
			num/=10;
			++count;
		}
		System.out.println("num of digits: "+count);
	}

}
