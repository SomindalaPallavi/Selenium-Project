package DAY_1;

public class Pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=30;
		switch(i){
		case 10:
			System.out.println("ten");
			break;
		case 20:
			System.out.println("twenty");
			break;
		case 30:
			System.out.println("thirty");
			break;
		default:
			System.out.println("fourty");
		}
	}

}
