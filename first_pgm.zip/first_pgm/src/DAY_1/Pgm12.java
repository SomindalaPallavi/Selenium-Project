package DAY_1;

public class Pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int i,j,k;
    for(i=5,j=4;i<=9;i++,j=j+2){
    	
    	System.out.println(i+"*"+j+"="+(i*j));
    }
    
 
    	

	}

}
