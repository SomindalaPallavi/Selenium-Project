package DAY_1;

public class Pgm16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0,count;
		for(int i=13;i<=30;i++)
		{
			count=0;
			for(int j=1;j<=i;j++)
			{
				if(i%j==0){
					count++;
				}
			}
			if(count==2){
				System.out.println(i);
				sum=sum+i;
			}
		}
		System.out.println(sum);
	}

}
