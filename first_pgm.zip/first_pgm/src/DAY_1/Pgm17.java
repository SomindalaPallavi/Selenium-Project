package DAY_1;

public class Pgm17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0,b=1,n=11,c,count;
		count=2;
		System.out.println(b);
		while(count<n){
			c=a+b;
			a=b;
			b=c;
			System.out.println(c);
			count++;
		}
	}

}
