package Feb_17;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class NewTest2 {
 
//  @BeforeMethod
//  public void beforeMethod() {
//	  System.out.println("before test method beforemethod will get execute");
//  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("After test method after method will get execute");
  }
  
  @Test
  public void t1() {
	 System.out.println("First Test Method ");
  }
  
 @Test
  public void t2() {
		 System.out.println("Second Test Method ");
	  }
  
  @Test
  public void t3() {
		 System.out.println("Third Test Method ");
	  }

}
