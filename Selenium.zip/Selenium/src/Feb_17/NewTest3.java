package Feb_17;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest3 {
	
	n_t3 jobj;
 
@BeforeMethod
  public void beforeMethod() {
	jobj=new n_t3();
  }

@Test
public void t1()
{
	jobj.login1();
}
}
