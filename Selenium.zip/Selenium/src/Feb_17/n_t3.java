package Feb_17;

public class n_t3 {
	
	public void login1(){
		
		System.out.println("login successful");
	}

}
