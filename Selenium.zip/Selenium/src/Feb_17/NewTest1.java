package Feb_17;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void t1() {
	 System.out.println("First Test Method ");
  }
  
 
  public void t2() {
		 System.out.println("Second Test Method ");
	  }
  
  @Test
  public void t3() {
		 System.out.println("Third Test Method ");
	  }
}