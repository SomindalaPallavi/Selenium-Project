package sauc_test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import sauc_pom.s_c;
import sauc_pom.s_pro;

public class s_t {
	
  WebDriver dr;
  s_c s;
  s_pro s1;
  String act_pro;
	
  @BeforeClass
  public void launchBrowser(){
			
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");//to launch the browser		
			
	dr=new ChromeDriver();
					
	dr.get("https://www.saucedemo.com/");//s=new s_c(dr);
 
  }
  
  @Test(priority=0)
  public void test_login_page() {
	  
	  s =new s_c(dr);
	  
	  String login_page_title=s.get_title();
	  
	  Assert.assertTrue(login_page_title.contains("Swag"));
  }
  
  @Test(priority=1)
  public void test_home_page() {
	  
	s.do_login("standard_user","secret_sauce");
	  
	s1=new  s_pro (dr);
	  
	String act_title=s1.get_displayed_title();
	  
	Assert.assertTrue(act_title.contains("Products"));
	
	System.out.println(act_title);
  }
  
  @Test(priority=2)
  public void pro_item_nmae(){
	  
	String act_name=s1.get_displayed_name();
	  
	Assert.assertTrue(act_name.contains("Sauce Labs Backpack"));
	
	System.out.println(act_name);
  }
  
  

}
