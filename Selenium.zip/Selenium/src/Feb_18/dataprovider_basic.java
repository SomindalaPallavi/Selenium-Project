package Feb_18;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class dataprovider_basic {
  @Test(dataProvider = "login_data")
  public void login(String eid, String pwd) {
	  System.out.println("email id: "+ eid +" pwd: "+pwd);
  }

  @DataProvider(name="login_data")
  public String[][] provide_data() {
     String[][] data={
    		 			{ "e1", "a" },
    		 			{ "e2", "b" },
     				 };
	return data;
  }
}
