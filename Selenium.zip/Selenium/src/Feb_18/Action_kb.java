package Feb_18;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Action_kb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver dr;
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver d1=new ChromeDriver();
		d1.get("http://demowebshop.tricentis.com/");
		d1.findElement(By.xpath("//div[@class='header-links-wrapper']//child::li[2]/a")).click();
		WebElement email=d1.findElement(By.xpath("//input[contains(@class,'email')]"));
		email.sendKeys("divya");
		Actions kbm=new Actions(d1);
		kbm.keyDown(email,Keys.SHIFT)
		.sendKeys(email,"divya")
		.keyUp(email, Keys.SHIFT)
		.build()
		.perform();
			
		
	}
		
		
				

}