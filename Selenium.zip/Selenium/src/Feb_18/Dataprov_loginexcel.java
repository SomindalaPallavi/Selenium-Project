package Feb_18;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Dataprov_loginexcel extends Dataprov_excel_cls {
	Dataprov_excel_cls test;
  @BeforeClass
  public void get_data() {
	  System.out.println("bm");
	  get_Test_data();
  }


@Test(dataProvider="login_data")
public void test1(String eid,String pwd,String exp_eid)
{
	test=new Dataprov_excel_cls();
	String a_eid=test.login(eid,pwd);
	System.out.println("act_res:"+a_eid);
    System.out.println("ex_res:"+a_eid);
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(a_eid, exp_eid);
	sa.assertAll();
	
	
}
@DataProvider(name="login_data")
public String[][] provide_data()
{
	return testdata;
}
}