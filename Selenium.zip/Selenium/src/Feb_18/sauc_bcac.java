package Feb_18;


import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.asserts.SoftAssert;

public class sauc_bcac {
	
	WebDriver dr;
	n_t3 jobj;
	
	int c=0;
	int[] pn={1,2};
	
@BeforeClass
 public void lau_bro() {
	
    jobj=new n_t3(dr);
	jobj.launchBrowser();
		
	jobj.login1("standard_user","secret_sauce");
	}

 
@BeforeMethod
public void BM(){
	  jobj.add_product(pn[c]);
	  c++;
	 
	  }
	
  
  @AfterMethod
public void AM(){
	
	if(c<2){
	  jobj.Continue();
	}
  }
@Test
public void t1(){
	  jobj.verify(1);
	  System.out.println("in test method t1");
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(jobj.act_n1, jobj.exp_n1);
	  sa.assertEquals(jobj.act_p1, jobj.e_p1);
	  sa.assertAll();
  }
	  
  
@Test
public void t2(){
	  jobj.verify(2);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(jobj.act_n1, jobj.exp_n1);
	  sa.assertEquals(jobj.act_p1, jobj.e_p1);
	  sa.assertAll();      
	  
  }

@AfterClass
public void AC(){ 
	  jobj.add_info();
	 
	  jobj.thankYouMsg();
	  }

}
