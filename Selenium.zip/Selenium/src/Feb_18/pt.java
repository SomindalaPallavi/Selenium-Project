package Feb_18;

import org.testng.annotations.Test;

public class pt {
  @Test(priority=1)
  public void login() {
	  System.out.println("in tm1");
  }
  @Test(priority=3)
  public void close() {
	  System.out.println("in tm3");
  }
  @Test(priority=2)
  public void add_product() {
	  System.out.println("in tm2");
  }
  
}
