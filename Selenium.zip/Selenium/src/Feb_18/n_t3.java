package Feb_18;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class n_t3 {
	WebDriver dr;
	String exp_n1,exp_p1;
	String e_p1;
	int count=0;
	String act_n1;
	String act_p1;
	
	public void launchBrowser(){
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");//to launch the browser		
		
		dr=new ChromeDriver();
				
		dr.get("https://www.saucedemo.com/");
		}
	public void login1(String eid,String pwd){
		
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys(eid);
		
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys(pwd);
		
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		
	}
	
	public n_t3(WebDriver dr){
		
		this.dr=dr;
	}
	public void add_product(int i) {
		  
		  
		 exp_n1=dr.findElement(By.xpath("//div[@class='inventory_item']["+i+"]//child::div[2]/a/div")).getText();//div[1],div[2]
		 exp_p1=dr.findElement(By.xpath("//div[@class='inventory_item']["+i+"]//child::div[3]//child::div[1]")).getText();//[1][2]
		  
		 e_p1=exp_p1.substring(1,exp_p1.length());
//		 System.out.println(e_p1);
//		 float ep1=Float.parseFloat(e_p1);
		  
		 dr.findElement(By.xpath("//div[@class='inventory_item']["+i+"]//child::div[3]//child::button")).click();//div[@class='pricebar']//add to cart
		 count++;  
		 dr.findElement(By.xpath("//span[@class='fa-layers-counter shopping_cart_badge']")).click();//after product has been added to the cart
		   
		 act_n1 = dr.findElement(By.xpath("//div[@class='cart_item']["+count+"]/div[2]//child::a/div")).getText();//div[3],div[4]
		 act_p1 = dr.findElement(By.xpath("//div[@class='cart_item']["+count+"]//child::div[2]//child::div[2]/div")).getText();//[1][2]
		 // float ap1 = Float.parseFloat(act_p1);
	  }
	  public void verify(int j) {
		  
		 
		  System.out.println("en1 "+exp_n1);
		  System.out.println("ep1 "+e_p1);
		  System.out.println("an1 "+act_n1);
		  System.out.println("ap1 "+act_p1);
		   
		  
		if((e_p1.equals(act_p1)==true)&&(exp_n1.compareTo(act_n1)==0))
			{
			System.out.println("PASS");
			
			}
			else
			{
			System.out.println("FAIL");
			}
	
	  }
	
	public void add_info() {


		  dr.findElement(By.xpath("//div[@class='cart_footer']/a[2]")).click(); //checkout
		  dr.findElement(By.xpath("//div[@class='subheader']")).click();
		  dr.findElement(By.xpath("//input[@id='first-name']")).sendKeys("pallu");
		  dr.findElement(By.xpath("//input[@id='last-name']")).sendKeys("sai");
		  dr.findElement(By.xpath("//input[@id='postal-code']")).sendKeys("51758");
		  dr.findElement(By.xpath("//input[@type='submit']")).click();
		  dr.findElement(By.xpath("//a[@class='btn_action cart_button']")).click();//finish

}
	  
	 
	  public void Continue(){
			//a[text()='Continue Shopping']
			dr.findElement(By.xpath("//div[@class='cart_footer']/a[1]")).click();//continue
		
		}
	  public void thankYouMsg(){
			String msg = dr.findElement(By.xpath("//h2[contains(text(),'THANK YOU')]")).getText();
			System.out.println(msg);
			}

}