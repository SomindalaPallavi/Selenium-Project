package Feb_18;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.asserts.SoftAssert;

public class dataprovider_login {
	dm_log dl=new dm_log();
	
  @Test(dataProvider = "login_data")
  public void test1(String eid, String pwd,String e_eid) {
	  
	String a_eid=dl.login(eid, pwd);
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(a_eid, e_eid);
	sa.assertAll();
//	System.out.println("email id: "+ a_eid +" pwd: "+ pwd +" email id: "+ "e_eid");
  }

  @DataProvider(name="login_data")
  public String[][] provide_data() {
     String[][] data={
    		 			{ "pallavisomindala@gmail.com", "9700914603","pallavisomindala@gmail.com" },//correct e_eid
    		 			{ "pallavisomindala@gmail.com", "9700914603","pallavisomindal@gmail.com" },//wrong e_eid
     				 };
	return data;
  }
}