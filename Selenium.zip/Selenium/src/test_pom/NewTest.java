package test_pom;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import library.utilities;
import page.log_page;
//import page.r_pag;
//import page.reg_pag;
import page.sign_page;

public class NewTest {
 
  WebDriver dr;
  sign_page sp;
//  r_pag rp;
//  reg_pag pr;
  log_page pl;
  utilities wt;

  String url="https://jpetstore.cfapps.io/catalog";
  @BeforeClass
  public void beforeClass() {
	  
	 wt=new utilities(dr);
	 dr= utilities.launch_browser("chrome", url);//chrome,firefox
  }
  
  @Test(priority=0)
  public void f() {
	  sp=new sign_page(dr);
	  sp.clk_sign();
  }
  
  
  @Test(priority=1)
  public void f3() {
	 System.out.println("pallu");
	 pl=new log_page(dr);
	 pl.do_login("pallupallu", "palpal@123");

  }
  
  @Test(priority=2)
  public void f4() {
	  wt=new utilities(dr);
	  wt.getScreenshot();
  }
  
  @AfterClass
  public void cl() {
	  dr.close();
  }
  

}
