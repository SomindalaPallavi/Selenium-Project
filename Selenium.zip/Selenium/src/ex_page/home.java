package ex_page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.utilities;

public class home {

	WebDriver dr;
	utilities wt;
	
	public home(WebDriver dr) {
		
		this.dr=dr;
		wt=new utilities(dr);
	}
	
	public void hm() {
		
		By lang=By.xpath("//select[@name='category_id']//child::option[2]");//programmable
		WebElement w_lang=wt.waitForElement(lang, 10);
		w_lang.click();
	}
	
	public void se() {
		
		By sea=By.xpath("//input[@name='DoSearch']");//search
		WebElement w_sea=wt.waitForElement(sea, 10);
		w_sea.click();
		
	}
	
	
}
