package ex_page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.utilities;

public class sp {


	WebDriver dr;
	utilities wt;
	
	public sp(WebDriver dr) {
		
		this.dr=dr;
		wt=new utilities(dr);
	}
	
	public void p() {
		
		By pro=By.xpath("//img[@src='images/books/020135358X.gif']");//img
		WebElement w_pro=wt.waitForElement(pro, 10);
		w_pro.click();
	}
}
