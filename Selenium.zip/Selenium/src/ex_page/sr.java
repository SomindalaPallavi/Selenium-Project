package ex_page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.utilities;

public class sr {


	WebDriver dr;
	utilities wt;
	
	public sr(WebDriver dr) {
		
		this.dr=dr;
		wt=new utilities(dr);
	}
	
	public void pn() {
		
		By pron=By.xpath("//td[@valign='top']//child::h1");//product name
		WebElement w_pron=wt.waitForElement(pron, 10);
		w_pron.getText();
	}
	
	
}
