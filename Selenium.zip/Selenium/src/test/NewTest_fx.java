package test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import EXCEL_UTIL.EXCEL_IO_ARR;
import library.utilities;
import page.log_page;
//import page.r_pag;
//import page.reg_pag;
import page.sign_page;

public class NewTest_fx extends EXCEL_IO_ARR {
 
//  private static final String[][] testdata = null;
  WebDriver dr;
  sign_page sp;
  log_page pl;
  utilities wt;
  EXCEL_IO_ARR  e;

  String url="https://jpetstore.cfapps.io/catalog";
  
  @BeforeClass
  public void beforeClass() { 
	  
	 get_Test_data();
//	 dr= utilities.launch_browser("firefox", url);
	 wt=new utilities(dr);
//	 wt.update_log("Completed Reading From excel");

  }
  
  @BeforeMethod
  public void lb() {
	  dr= utilities.launch_browser("firefox", url);
  }
 
 
  
  @Test(dataProvider="data")
  
  public void login(String uid,String pwd)
  {
	  
	  
	  sp=new sign_page(dr);
	  sp.clk_sign();
	  try {
	  pl=new log_page(dr);
	  pl.do_login(uid,pwd);
	  System.out.println("firefox browser launched");
	  }catch(java.lang.NullPointerException pal) {
		  System.out.println("exception occured");
	  }
	  System.out.println("login successful with (pallupallu) and (palpal@123)");
//	  SoftAssert sa=new SoftAssert();
//	  sa.assertEquals(uid, pwd);
//	  sa.assertAll();
//	  System.out.println("eid :" +uid + " pwd : "+pwd);
  }
  
  @DataProvider(name="data")
  public String[][] provide_data()
  {
  return testdata;

  }
  
//  @AfterClass
//  public void close()
//  {
//  dr.close();
//  }
//  
  }


