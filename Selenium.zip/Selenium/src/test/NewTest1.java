package test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import EXCEL_UTIL.EXCEL_IO_ARR;
import library.utilities;
import page.log_page;
//import page.r_pag;
//import page.reg_pag;
import page.sign_page;

public class NewTest1 {
 
  private static final String[][] testdata = null;
  WebDriver dr;
  sign_page sp;
//  r_pag rp;
//  reg_pag pr;
  log_page pl;
  utilities wt;
  EXCEL_IO_ARR  e;

  String url="https://jpetstore.cfapps.io/catalog";
  @BeforeClass
  public void beforeClass() {
//	  wt=new utilities(dr);
//	  dr= utilities.launch_browser("chrome", url);//chrome,firefox
	  e=new EXCEL_IO_ARR ();
	  e.get_Test_data();
	
  }
  
//  @Test(priority=0)
//  public void f() {
//	  sp=new sign_page(dr);
//	  sp.clk_sign();
//  }
  
//  @Test(priority=1)
//  public void f1() {
//	  rp=new r_pag(dr);
//	  rp.clk_reg();
//  }
//  
//  @Test(priority=2)
//  public void f2() {
//	 pr=new reg_pag(dr); 
//	 pr.do_reg();
//  }
  
  @Test(dataProvider="login_data")
  public void f3(String eid,String pwd) {
//	  String eid1="pallupallu";
//	  String pwd1="palpal@123";
//	 System.out.println("pallu");
//	 pl=new log_page(dr);
//	 pl.do_login(eid1, pwd1);
//	 System.out.println("act_res:"+eid1);
//	 System.out.println("ex_res:"+pwd1);
//	 SoftAssert sa=new SoftAssert();
//	 sa.assertEquals(eid1, pwd1);
//	 sa.assertAll();
	  System.out.println("eid :" +eid + " pwd : "+pwd);

  }
  
  @DataProvider(name="login_data")
  public String[][] provide_data()
  {
  	return testdata;
  }
  
/*  @Test
  public void f4() {
	  wt=new utilities(dr);
	  wt.getScreenshot();
  }
  */
//  @AfterClass
//  public void cl() {
//	  dr.close();
//  }
  

}
