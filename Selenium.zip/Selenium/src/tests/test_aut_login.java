package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import pages.aut_home_page;
import pages.aut_login_page;

public class test_aut_login {
	
	WebDriver dr;
	
	aut_home_page homepage;
	
	aut_login_page loginpage;
 
  @BeforeClass
  public void beforeClass() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  dr=new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/login");
	  
  }
  
  @Test(priority=0)
  public void test_login_page() {
	  
	  loginpage=new aut_login_page(dr);
	  
	  String login_page_title=loginpage.get_title();
	  
	  Assert.assertTrue(login_page_title.contains("Shop"));
  }
  
  @Test(priority=2)
  public void test_home_page() {
	  
	  loginpage.do_login("pallavisomindala@gmail.com","9700914603");
	  
	  homepage=new aut_home_page(dr);
	  
	  String actual_eid=homepage.get_displayed_eid();
	  
	  Assert.assertTrue(actual_eid.contains("pallavisomindala@gmail.com"));
  }
  
  

}
