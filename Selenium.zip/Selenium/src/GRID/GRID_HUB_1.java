package GRID;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GRID_HUB_1 {
	
	WebDriver dr;
	String autURL,nodeURL;
	@BeforeClass
	public void setup() throws MalformedURLException
	{
		autURL ="http://demowebshop.tricentis.com";
		nodeURL ="http://192.168.0.234:5566/wd/hub";
		DesiredCapabilities cap= DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
		dr=new RemoteWebDriver(new URL(nodeURL),cap);
	
		
	}
	
	
	
    @Test
    public void f() {
    	dr.get(autURL);
    }
    
    public void aftertest()
	{
		dr.quit();
	}
}
