package KWDFW;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class all_webelement_fns {

	WebDriver dr;
	//creating a constructor
	all_webelement_fns(WebDriver dr)
	{
		this.dr=dr;
	}
	//passing xpath and assigning the data to it
	public void enter_txt(String xp,String data)
	{
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	
	public void click(String xp)
	{
		dr.findElement(By.xpath(xp)).click();
	}
	//to launch the browser
	public void launchChrome(String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
}
