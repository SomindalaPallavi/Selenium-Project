package KWDFW;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operations {

String filename="C:\\Users\\BLTuser.BLT223\\Desktop\\New folder\\KWDFW.xlsx",sheetname="Sheet1";

	public String read_excel(int r, int c) {
		// TODO Auto-generated method stub
		
		String s=null;
		
		 try {
		    	File f=new File(filename);
				FileInputStream fis=new FileInputStream(f);//reading the input from the excel file to java script
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet(sheetname);//to get the sheetname
				XSSFRow row=sh.getRow(r);
				XSSFCell cell=row.getCell(c);
			    s=cell.getStringCellValue();
				System.out.println(s);
				
			
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return(s);
	}

}
