package s_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Child {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		dr.findElement(By.xpath("//div[@class='inputs']//child::input"));
		dr.findElement(By.xpath("//div[@class='inputs'][2]//child::input"));
		dr.findElement(By.xpath("//div[@class='buttons']//child::input[@value='Log in']"));
		

	}

}
