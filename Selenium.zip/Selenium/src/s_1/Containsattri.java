package s_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Containsattri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		dr.findElement(By.xpath("//input[contains(@class,'email')]"));
		dr.findElement(By.xpath("//input[contains(@class,'password')]"));
		dr.findElement(By.xpath("//input[contains(@value,'Log in')]"));
		
	}

}
