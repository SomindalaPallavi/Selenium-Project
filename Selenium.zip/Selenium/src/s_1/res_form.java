package s_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class res_form {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		
		WebDriver dr=new ChromeDriver();
		
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
//		dr.findElement(By.xpath("//a[@href='Registration.php']//img")).click();//Registration
		dr.findElement(By.xpath("//input[@name='user_login']")).sendKeys("Pallavi");
		dr.findElement(By.xpath("//input[@name='user_password']")).sendKeys("pallupooja");
		dr.findElement(By.xpath("//input[@name='first_name']")).sendKeys("S");
		dr.findElement(By.xpath("//input[@name='last_name']")).sendKeys("Pallavi");
		dr.findElement(By.xpath("//input[@name='email']")).sendKeys("pallavisomindala@gmail.com");
		dr.findElement(By.xpath("//input[@name='address1']")).sendKeys("d/no:1-325-30/1,");
		dr.findElement(By.xpath("//input[@name='address2']")).sendKeys("Lakshmi Nagar,Puttur-517583,");
		dr.findElement(By.xpath("//input[@name='address3']")).sendKeys("Chittoor");
		dr.findElement(By.xpath("//input[@name='city']")).sendKeys("Puttur");
		dr.findElement(By.xpath("//select[@name='state_id']//child::option[2]")).click();
		dr.findElement(By.xpath("//input[@name='zip']")).sendKeys("51758");
		dr.findElement(By.xpath("//select[@name='country_id']//child::option[113]")).click();
		dr.findElement(By.xpath("//input[@name='phone_home']")).sendKeys("9700914603");
		dr.findElement(By.xpath("//input[@name='phone_work']")).sendKeys("7989282815");
		dr.findElement(By.xpath("//select[@name='language_id']")).sendKeys("English");
		dr.findElement(By.xpath("//select[@name='age_id']")).sendKeys("22");
		dr.findElement(By.xpath("//select[@name='gender_id']")).sendKeys("Female");
		dr.findElement(By.xpath("//select[@name='education_id']")).sendKeys("Graduate");
		dr.findElement(By.xpath("//select[@name='income_id']")).sendKeys("$25,000-$33,000");
		dr.findElement(By.xpath("//textarea[@name='note']")).sendKeys("Describe about yourself");
		dr.findElement(By.xpath("//input[@name='Insert']")).click();
		try{
		String m=dr.findElement(By.xpath("//tr[@class='Error']//child::td")).getText();
		System.out.println(m);
		}
		catch(org.openqa.selenium.NoSuchElementException m1){
			System.out.println("Getting exception");
		}
	}

}
