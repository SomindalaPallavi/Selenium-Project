package s_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class st {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	    int q1=2;
	    int send;
	    String q;
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		
		WebDriver dr=new ChromeDriver();
		
		dr.get("http://examples.codecharge.com/store/Default.php");
		
		
		String tit_ac=dr.getTitle();
		System.out.println(tit_ac);
		String tit_ex="Online Bookstore";
		if(tit_ac.compareTo(tit_ex)==0){
			System.out.println("Pass");
		}
		else{
			System.out.println("Fail");
		}
		dr.findElement(By.xpath("//a[@class='TopMenuLink']")).click();//a[@class='TopMenuLink']//home
		dr.findElement(By.xpath("//select[@name='category_id']//child::option[3]")).click();//select[@name='category_id']//all id's
		dr.findElement(By.xpath("//input[@name='DoSearch']")).click();//input[@name='DoSearch']//search
		dr.findElement(By.xpath("//td[@width='150']//child::img")).click();	//td[@width='150']//child::img//img
		String in=dr.findElement(By.xpath("//td[@valign='top']//child::h1")).getText();//td[@valign='top']//h1//img name
		System.out.println(in);
		String p=dr.findElement(By.xpath("//td[@colspan='2']")).getText();	//td[@colspan='2']//price
		String p1=p.substring(8,p.length());
//		System.out.println(p1);
		float p2=Float.parseFloat(p1);
		System.out.println(p2);
		
		dr.findElement(By.xpath("//input[@name='quantity']")).clear();//to clear the quantity
		dr.findElement(By.name("quantity")).sendKeys("2");
		
		
		dr.findElement(By.xpath("//input[@name='Insert1']")).click();//input[@name='Insert1']//Add to Shopping Cart
		
		String t=dr.findElement(By.xpath("//tr[@class='Row']//child::td[4]")).getText();//tr[@class='Row']//child::td[4]//Total
		String t1=t.substring(1,t.length());
//		System.out.println(t1);
		
		float t2=Float.parseFloat(t1);
	    System.out.println(t2);
	    
	    q=dr.findElement(By.xpath("//tr[@class='Row']//child::td/input")).getAttribute("value");
	    q1=Integer.parseInt(q);
	    System.out.println(q1);
	   
//	    try{
//	    String q=dr.findElement(By.xpath("//tr[@class='Row']//child::td/input1")).getAttribute("value");
//	    q1=Integer.parseInt(q);
//	    System.out.println(q1);
//		
//	    }
//	    catch(org.openqa.selenium.NoSuchElementException qq){
//	    	System.out.println("Getting Exception");
//	    	send=q1;
//	    }
//	    System.out.println(q);
	    
	
		
		float mul=p2*q1;
		System.out.println("mul :"+mul);

	    if(mul==t2){
	    	System.out.println("Pass");
	    }
	    else
	    {
	    	System.out.println("Fail");
	    }
	    dr.findElement(By.xpath("//input[@name='Submit']")).click();//input[@name='Submit']//Submit
		dr.findElement(By.xpath("//input[@name='purchase']")).click();//input[@name='purchase']//Click here to Purchase
		
		}

}
