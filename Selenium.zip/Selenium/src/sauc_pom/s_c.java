package sauc_pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class s_c {
	
	WebDriver dr;
	
	
	@FindBy(xpath="//input[@type='text']")
	WebElement uname;
	
	@FindBy(xpath="//input[@type='password']")
	WebElement pwd;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement btn;
	
	public s_c(WebDriver dr){
		
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public void set_uname(String un){
		
		uname.sendKeys(un);
	}
	
	public void set_pwd(String pword){
		
		pwd.sendKeys(pword);
	}
	

	public void clk_btn()
	{
		btn.click();
	}

	public void do_login(String u,String p){
		
		this.set_uname(u);
		this.set_pwd(p);
		this.clk_btn();
	}

    public String get_title(){
		
		return dr.getTitle();
	}

	
}
