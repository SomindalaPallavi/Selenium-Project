package sauc_pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class s_pro {

	WebDriver dr;
	
	@FindBy(xpath="//div[@class='product_label']")
	WebElement prot;
	
	@FindBy(xpath="//div[@class='inventory_item'][1]//div[2]//child::div")
	WebElement prof_xp;
	
	public  s_pro(WebDriver dr){
		
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public String get_displayed_title(){
		
		return prot.getText();
	}

	public String get_displayed_name(){
		
		return prof_xp.getText();
	}
}
