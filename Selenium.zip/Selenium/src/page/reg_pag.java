package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.utilities;

public class reg_pag {

	WebDriver dr;
	utilities wt;
	

	public reg_pag(WebDriver dr) {
		
		this.dr=dr;
		wt=new utilities(dr);
	}
	
	
	
	public void set_ui(String u1){

		By by_uid=By.xpath("//div[@id='Catalog']//tr[1]//child::td[2]//input");
		WebElement we_uid=wt.waitForElement(by_uid,20);
		we_uid.sendKeys("pallupallu");
	}
	
	public void set_n(String n1){
		By by_np=By.xpath("//div[@id='Catalog']//tr[2]//child::td[2]//input");
		WebElement we_np=wt.waitForElement(by_np,20);
		we_np.sendKeys("palpal@123");
	}
	
	public void set_r(String r1){
		By by_rp=By.xpath("//div[@id='Catalog']//tr[3]//child::td[2]//input");
		WebElement we_rp=wt.waitForElement(by_rp,20);
		we_rp.sendKeys("palpal@123");
	}
	
	public void set_f(String f1) {
		
		By by_fn=By.xpath("//div[@id='Catalog']//div//child::tr[1]//input");
		WebElement we_fn=wt.waitForElement(by_fn,20);
		we_fn.sendKeys("S");
	}
	
	public void set_l(String l1) {
		By by_ln=By.xpath("//div[@id='Catalog']//div//child::tr[2]//input");
		WebElement we_ln=wt.waitForElement(by_ln,20);
		we_ln.sendKeys("Pallavi");
	}
	
	public void set_e(String e1) {
		By by_ei=By.xpath("//div[@id='Catalog']//div//child::tr[3]//input");
		WebElement we_ei=wt.waitForElement(by_ei,20);
		we_ei.sendKeys("pallavisomindala@gmail.com");
	}
	
	public void set_p(String p1) {
		By by_ph=By.xpath("//div[@id='Catalog']//div//child::tr[4]//input");
		WebElement we_ph=wt.waitForElement(by_ph,20);
		we_ph.sendKeys("7989282815");
	}
	
	public void set_a(String a1) {
		By by_ad1=By.xpath("//div[@id='Catalog']//div//child::tr[5]//input");
		WebElement we_ad1=wt.waitForElement(by_ad1,20);
		we_ad1.sendKeys("puttur");
	}
	
	public void set_ad(String ad1) {
		By by_ad2=By.xpath("//div[@id='Catalog']//div//child::tr[6]//input");
		WebElement we_ad2=wt.waitForElement(by_ad2,20);
		we_ad2.sendKeys("chittoor");
	}
	
	public void set_c(String c1) {
		By by_ci=By.xpath("//div[@id='Catalog']//div//child::tr[7]//input");
		WebElement we_ci=wt.waitForElement(by_ci,20);
		we_ci.sendKeys("puttur");
	}
	
	public void set_s(String s1) {
		By by_st=By.xpath("//div[@id='Catalog']//div//child::tr[8]//input");
		WebElement we_st=wt.waitForElement(by_st,20);
		we_st.sendKeys("Andhra Pradesh");
	}
	
	public void set_z(String z1) {
		By by_zi=By.xpath("//div[@id='Catalog']//div//child::tr[9]//input");
		WebElement we_zi=wt.waitForElement(by_zi,20);
		we_zi.sendKeys("517583");
	}
	
	public void set_co(String co1) {
		By by_cou=By.xpath("//div[@id='Catalog']//div//child::tr[10]//input");
		WebElement we_cou=wt.waitForElement(by_cou,20);
		we_cou.sendKeys("India");
		
	}
	
	public void set_ll(String l1){
		
		By by_lp=By.xpath("//div[@id='Catalog']//table[2]//child::tr[1]//select");
		WebElement we_lp=wt.waitForElement(by_lp,20);
		we_lp.sendKeys("English");
	}
	
	public void set_cf(String cf1) {
		By by_fc=By.xpath("//div[@id='Catalog']//table[2]//child::tr[2]//select");
		WebElement we_fc=wt.waitForElement(by_fc,20);
		we_fc.sendKeys("BIRDS");
	}
	
	public void set_m() {
		By by_ml=By.xpath("//div[@id='Catalog']//table[2]//child::tr[3]//input");
		WebElement we_ml=wt.waitForElement(by_ml,20);
		we_ml.click();
	}
	
	public void set_b() {
		By by_mb=By.xpath("//div[@id='Catalog']//table[2]//child::tr[4]//input");
		WebElement we_mb=wt.waitForElement(by_mb,20);
		we_mb.click();
	}
	
	public void set_sv() {
		By by_v=By.xpath("//input[@id='save']");
		WebElement we_v=wt.waitForElement(by_v,20);
		we_v.click();
	}
	
	public String do_reg(){
		
		this.set_ui("pallupallu");
		this.set_n("palpal@123");
		this.set_r("palpal@123");
		this.set_f("S");
		this.set_l("Pallavi");
		this.set_e("pallavisomindala@gmail.com");
		this.set_p("7989282815");
		this.set_a("puttur");
		this.set_ad("chittoor");
		this.set_c("puttur");
		this.set_s("Andhra Pradesh");
		this.set_z("517583");
		this.set_co("India");
		this.set_ll("English");
		this.set_cf("BIRDS");
		this.set_m();
		this.set_b();
		this.set_sv();
		return null;
		
	}
	
//	public String get_title(){
//		
//		return dr.getTitle();
//	}
	

	
	
}
