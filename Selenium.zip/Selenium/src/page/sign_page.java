package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.utilities;

public class sign_page {
	WebDriver dr;
	utilities wt;

	
	public sign_page(WebDriver dr){
		
		this.dr=dr;
		wt=new utilities(dr);
	}
	public void clk_sign(){

		By by_un=By.xpath("//div[@id='MenuContent']//a[2]");
		WebElement we_un=wt.waitForElement(by_un,20);
		we_un.click();
		
	}
}
