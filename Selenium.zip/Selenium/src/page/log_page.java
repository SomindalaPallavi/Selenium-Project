package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.utilities;

public class log_page {
	
	WebDriver dr;
	utilities wt;

	
	public log_page(WebDriver dr){
		
		this.dr=dr;
		wt=new utilities(dr);
	}
	
	public void set_un(String u){
		
//		By by_un=By.xpath("//div[@id='Catalog']//p[2]//child::input[1]");
		By by_un=By.xpath("//input[@name='username']");
		WebElement we_un=wt.waitForElement(by_un,20);
		we_un.sendKeys(u);
	}
	
	public void set_pw(String p){
		
//		By by_pw=By.xpath("//div[@id='Catalog']//p[2]//child::input[2]");
		By by_pw=By.xpath("//input[@name='password']");
		WebElement we_pw=wt.waitForElement(by_pw,20);
		we_pw.sendKeys(p);
	}
	
	

	public void clk_btn()
	{
		By btn=By.xpath("//input[@id='login']");
		WebElement we_btn=wt.waitForElement(btn,20);
		we_btn.click();
	}
	
	public void do_login(String u1,String p1){
		
		this.set_un(u1);
		this.set_pw(p1);
		this.clk_btn();
		
		
	}
	
//	public String get_title(){
//		
//		return dr.getTitle();
//	}
	
}