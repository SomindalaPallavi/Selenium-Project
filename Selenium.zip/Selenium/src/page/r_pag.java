package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import library.utilities;

public class r_pag {

	WebDriver dr;
	utilities wt;
	
	
	public r_pag(WebDriver dr){
		
		this.dr=dr;
		wt=new utilities(dr);
	}
	public void clk_reg(){

		By by_r=By.xpath("//div[@id='Catalog']//a");
		WebElement we_r=wt.waitForElement(by_r,10);
		we_r.click();
		
	}
}
