package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class aut_home_page {
	
	WebDriver dr;
	
	By profile_xp=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");//registered email id path
	
	public aut_home_page(WebDriver dr){
		
		this.dr=dr;
	}
	
	public String get_displayed_eid(){
		
		return dr.findElement(profile_xp).getText();
	}
}
