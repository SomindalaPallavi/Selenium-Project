package WEBDRIVER_BASICS;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Books {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the no: ");
		Scanner scanner=new Scanner(System.in);
		int s=scanner.nextInt();
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		
		WebDriver dr=new ChromeDriver();
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		String s1="pallavisomindala@gmail.com";
		
		
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("pallavisomindala@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("9700914603");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
//		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]/a")).getText();
		//div[@class='header-menu']//child::li[1]/a
		dr.findElement(By.xpath("//div[@class='header-menu']//child::li[1]/a")).click();
		for(int i=1;i<=7;i++) {
			
			if(i==s)
			{
		dr.findElement(By.xpath("//div[@class='item-box']["+i+"]")).click();//all books
		
			}
		}
		String str=dr.findElement(By.xpath("//a[@class='product-name']")).getText();//getting the particular product name 
		System.out.println(str);
		String str1=dr.findElement(By.xpath("//td[@class='unit-price nobr']//child::span[2]")).getText();//getting that product price
		System.out.println(str1);
		//dr.findElement(By.xpath("//div[@class='header-links']//ul/child::li[3]/a/span[1]")).click();
		dr.findElement(By.xpath("//tr[@class='cart-item-row']//child::td[1]")).click();//remove the product from the cart
		dr.findElement(By.xpath("//div[@class='common-buttons']//child::input")).click();//will update the cart

	}
}