package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class l_v_iv{
	int r,c;
	
	public String read_excel(String Filename,String Sheetname,int r,int c){
		
		String s = null;
		 try {
		    	File f=new File(Filename);
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet(Sheetname);
				XSSFRow row=sh.getRow(r);
				XSSFCell cell=row.getCell(c);
			    s=cell.getStringCellValue();
				System.out.println(s);
				
			
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return s;
		     
			}
	
public static String write_excel(String Filename , String Sheetname,int r,int c,String n){
	
		
		String s = null;
		 try {
		    	File f=new File(Filename);
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet(Sheetname);
				
				XSSFRow row=sh.getRow(r);
				XSSFCell cell=row.createCell(c);
				cell=row.getCell(c);
//			    s=cell.getStringCellValue();
//				System.out.println(s);
				
				cell.setCellValue(n);
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
		 		
			
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return s;
		     
			}
	
	
	public String login(String eid,String pwd){
		String act_res;
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		
		WebDriver dr=new ChromeDriver();
	
		
		
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys(eid);
		dr.findElement(By.id("Password")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		try{
			act_res = dr.findElement(By.xpath("//div[@class='inputs']//child::span[1]/span")).getText();
			
		}catch(org.openqa.selenium.NoSuchElementException pallavi1){
		try{
			act_res = dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
			
		}
		catch(org.openqa.selenium.NoSuchElementException pallavi){
			act_res=dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]/a")).getText();//will take the mail after we got logged
		}
		
		//div[@class='inputs']//child::span[1]/span
		}
		dr.close();
		return act_res;
	}




	public static void main(String[] args) {
		// TODO Auto-generated method stub
		l_v_iv e=new l_v_iv();
		String test_result;
		String m="C:\\Users\\BLTuser.BLT223\\Desktop\\New folder\\3.xlsx";
		String p="Sheet1";
//		int r = 1;
	    for(int r=1;r<=4;r++){
		String sa=e.read_excel(m,p,r,0);//read mail from the excel file
		if(sa.compareTo("blank")==0)
			sa=" ";
		System.out.println(sa);
		String si=e.read_excel(m,p,r,1);//read pwd from the excel file
//		if(si.compareTo("blank")==0)
//			si=" ";
		String si1=si.substring(1,si.length()-1);
		System.out.println(si1);
		String exp=e.read_excel(m,p,r,2);//read expected result from the excel file
		System.out.println(exp);
		
		String act_emailid=e.login(sa, si1);
		
		
		if(act_emailid.equals(exp)==true){
			test_result="pass";
			
		}
		else{
			test_result="fail";
		}
		
	
		String Actual= write_excel(m,p,r,3,act_emailid);//write actual result in the excel file
		String res=write_excel(m,p,r,4,test_result);// write test result(p/f) in the excel file
		}
	
	}
	
}
