package WEBDRIVER_BASICS;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class product {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the no: ");
		Scanner scanner=new Scanner(System.in);
		int s=scanner.nextInt();
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		
		WebDriver dr=new ChromeDriver();
		String s1="pallavisomindala@gmail.com";
		
		
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("pallavisomindala@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("9700914603");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]/a")).getText();
//		for(int i=1;i<=7;i++)
//		{
//			if(i==s){
//				dr.findElement(By.xpath("//div[@class='item-box'][1]//child::input")).click();
				
				//dr.findElement(By.xpath("//li[@id='topcartlink']")).click();
				
				//dr.findElement(By.xpath("//td[@class='remove-from-cart']")).click();
				
				
				//dr.findElement(By.xpath("//input[@value='Update shopping cart']")).click();
//			}
//		}
		
	}

}
