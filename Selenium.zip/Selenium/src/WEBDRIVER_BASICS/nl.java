package WEBDRIVER_BASICS;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class nl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		String xp="/html/body/div[4]/div[1]/div[1]dic[2]/div[1]/ul/li[2]/a1",
				xp1="/html/body/div[4]/div[1]/div[1]dic[2]/div[1]/ul/li[2]/a";
		WebElement we;
		
		WebDriverWait wt=new WebDriverWait(dr,20);
		we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp)));
		we.click();
		
	}

}
