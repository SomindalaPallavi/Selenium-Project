package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelements_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		
		WebDriver dr=new ChromeDriver();
		String s1="pallavisomindala@gmail.com";
		
		
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys("pallavisomindala@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("9700914603");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input   ")).click();
		
		String s=dr.findElement(By.linkText("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		
		int m=s.compareTo(s1);
		if(m==0)
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
	}

}