package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class inv {
static String p;
	public String login(String eid,String pwd){
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		
		WebDriver dr=new ChromeDriver();
	
		
		
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.linkText("Log in")).click();
		dr.findElement(By.id("Email")).sendKeys(eid);
		dr.findElement(By.id("Password")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		String p=dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
//		System.out.println(p);
//		String p1=dr.findElement(By.xpath("//span[@class='field-validation-error']//child::span")).getText();
//		System.out.println(p1);
		return p;
	}

	public static void main(String[] args) {
		inv l=new inv();
		String em="pallavisomindala@gmail.com";
		String pw="97009";
		//String m="C:\\Users\\BLTuser.BLT223\\Desktop\\New folder\\2.xlsx";
		
		
//      l.login("pallavisomindala@gmail.com", "97009");
//		l.login(" ","9700914603");
//		l.login(" ","97009");
		String p2=l.login(em, pw);
		String s=p2;
		if(p2.equals(s)==true){
			System.out.println("pass");
		}
		else{
			System.out.println("fail");
			
		}
		
	}

}