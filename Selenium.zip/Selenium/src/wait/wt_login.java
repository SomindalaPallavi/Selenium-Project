package wait;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class wt_login {
	static WaitTypes wt;
	static WebDriver dr;
	public static String login(String eid,String pwd) {
		
		wt = new WaitTypes(dr);
//		String a_result;
		
		By by_eid=By.xpath("//input[@class='email']");
		WebElement we_eid=wt.waitForElement(by_eid, 20);
		we_eid.sendKeys(eid);
		
		By by_pwd=By.xpath("//input[@class='password']");
		WebElement we_pwd=wt.waitForElement(by_eid, 20);
		we_pwd.sendKeys(pwd);
		
		By by_btn=By.xpath("//input[@value='Log in']");
		WebElement we_btn=wt.waitForElement(by_eid, 20);
		we_btn.click();
		
		return pwd;
		
	}
}
