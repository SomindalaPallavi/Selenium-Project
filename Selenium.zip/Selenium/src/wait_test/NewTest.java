package wait_test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import wait.wt_login;

public class NewTest {
	  wt_login  l;
	  WebDriver dr;
  @Test
  public void login_test() {
	  
	l=new login(dr);
  }
}
