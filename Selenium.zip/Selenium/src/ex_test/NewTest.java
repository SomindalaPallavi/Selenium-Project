package ex_test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import library.utilities;

public class NewTest {
	
	 WebDriver dr;
	 utilities wt;
	 
	 String url="http://examples.codecharge.com/Store/Default.php";
	  @BeforeClass
	  public void beforeClass() {
		  
		 wt=new utilities(dr);
		 dr= utilities.launch_browser("firefox", url);//chrome,firefox
		 String tit_ac=dr.getTitle();
		 System.out.println(tit_ac);
		 String tit_ex="Online Bookstore";
		 if(tit_ac.compareTo(tit_ex)==0){
				System.out.println("Pass");
		 }
		 else{
				System.out.println("Fail");
		 }
	  }
	  
  @Test
  public void f() {
	  
	  
  }
}
