package Date_cal;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class calen {
	
	static String cur_month_yr;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//input[@type='text']
		
	
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html"); 
		dr.findElement(By.xpath("//input[@id='datepicker']")).click();
		cur_month_yr=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		
		String act_month_yr="April 2020";
		while(!act_month_yr.equals(cur_month_yr)) {
			
			dr.findElement(By.xpath("//div[@class='ui-datepicker-header ui-widget-header ui-helper-clearfix ui-corner-all']//a[2]")).click();
			cur_month_yr=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		}
		
		
		List<WebElement> dates=dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));
		
		for(WebElement e:dates) {
			
			String date=e.getText();
			
			if(date.equalsIgnoreCase("2"))
			{
				e.click();
								
				break;
			}
		}
		
		
	}

}
